//	Andrew Rodrigues
//	11/9/2015
//	Version 3.0
//	jQuery Slideshow
//	Changes background image & preloads

var galleryImages = [
	{
		image: "url('1.jpg')",
		title: "jQuery Slideshow Plugin 3.0",
	},
	{
		image: "url('2.jpg')",
		title: "Modern Browser Support",
	},
	{
		image: "url('3.jpg')",
		title: "Easily Editable Clean Code",
	},
	{
		image: "url('4.jpg')",
		title: "Template & CSS Included",
	},
	{
		image: "url('5.jpg')",
		title: "Download & Use It!",
	},
];

var i = 1;
preload = ['1.jpg','2.jpg','3.jpg','4.jpg','5.jpg'];

$(document).ready(function() {
	for (var j = 0; j < preload.length; j++) {
		$('#preload').append('<img src="' + preload[j] + '">');
	}
});

var change = function changeImage() {
	if (i >= galleryImages.length) {
		i = 0;
	};
	var nextImage = galleryImages[i].image;
	$('#fullGallery').css('background-image', galleryImages[i].image);
	$('#title').text(galleryImages[i].title)
	i = i + 1;
}

$('#fullGallery').css('background-image', galleryImages[0].image)
$('#title').text(galleryImages[0].title)

setInterval(change,3000);